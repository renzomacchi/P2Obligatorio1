/*Santiago Clavere
  Renzo Machi
*/
package obligatorio1;

public abstract class Color {
    public final static String RESET = "\u001B[0m";
    public final static String FONDO_VERDE = "\u001B[42m";
    public final static String FONDO_AMARILLO = "\u001B[43m";
    public final static String ROJO = "\u001B[31m";
    public final static String AZUL = "\u001B[34m";
}
